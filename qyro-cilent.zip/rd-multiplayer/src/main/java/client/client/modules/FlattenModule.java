package client.client.modules;

import client.Minecraft;
import client.client.module.Module;
import client.net.SocketClient;
import global.Packets;

import java.util.ArrayDeque;
import java.util.Deque;

public class FlattenModule extends Module {

    private static final int  RADIUS      = 10;
    private static final long MS_PER_BREAK = 210;

    private final Deque<int[]> queue = new ArrayDeque<>();
    private boolean queued = false;
    private long lastBreak = 0;

    public FlattenModule() {
        super("Flatten", "Flattens terrain around you", Category.MISC);
        setKeybind(org.lwjgl.input.Keyboard.KEY_F6);
    }

    @Override
    public void onEnable() {
        queue.clear();
        queued = false;
    }

    @Override
    public void onDisable() {
        queue.clear();
        queued = false;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.mc;
        if (mc == null || mc.localPlayer == null || mc.level == null) return;
        if (mc.chat != null && mc.chat.toggled) return;

        if (!queued) {
            int cx = (int) Math.floor(mc.localPlayer.x);
            int cy = (int) Math.floor(mc.localPlayer.y);
            int cz = (int) Math.floor(mc.localPlayer.z);
            // Break everything above floor level in radius
            for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                    for (int dy = 1; dy <= 5; dy++) {
                        int bx = cx + dx, by = cy + dy - 1, bz = cz + dz;
                        if (mc.level.isSolidTile(bx, by, bz))
                            queue.add(new int[]{bx, by, bz});
                    }
                }
            }
            queued = true;
        }

        if (queue.isEmpty()) { setEnabled(false); return; }

        long now = System.currentTimeMillis();
        if (now - lastBreak < MS_PER_BREAK) return;
        lastBreak = now;

        int attempts = 0;
        while (!queue.isEmpty() && attempts < 20) {
            int[] b = queue.poll();
            attempts++;
            if (!mc.level.isSolidTile(b[0], b[1], b[2])) continue;
            double dx = b[0]+0.5-mc.localPlayer.x, dy = b[1]+0.5-mc.localPlayer.y, dz = b[2]+0.5-mc.localPlayer.z;
            if (Math.sqrt(dx*dx+dy*dy+dz*dz) > 9.5) { queue.addLast(b); continue; }
            try {
                mc.level.setTile(b[0], b[1], b[2], 0);
                SocketClient.sendBlock(Packets.BLOCK_BREAK, b[0], b[1], b[2]);
            } catch (Exception e) { }
            break;
        }
    }
}
