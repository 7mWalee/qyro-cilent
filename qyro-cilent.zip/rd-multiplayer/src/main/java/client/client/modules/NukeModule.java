package client.client.modules;

import client.Minecraft;
import client.client.module.Module;
import client.net.SocketClient;
import global.Packets;

import java.util.ArrayDeque;
import java.util.Deque;

public class NukeModule extends Module {

    private static final int  RADIUS       = 50;
    private static final int  DEPTH        = 3;
    private static final long MS_PER_BREAK = 210; // ~4.7/sec, under 5/sec limit

    private final Deque<int[]> queue = new ArrayDeque<>();
    private boolean queued = false;
    private long lastBreak = 0;

    public NukeModule() {
        super("Nuke", "Obliterates 100x100 area around you", Category.MISC);
        setKeybind(org.lwjgl.input.Keyboard.KEY_END);
    }

    @Override
    public void onEnable() {
        queue.clear();
        queued = false;
    }

    @Override
    public void onDisable() {
        queue.clear();
        queued = false;
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.mc;
        if (mc == null || mc.localPlayer == null || mc.level == null) return;
        if (mc.chat != null && mc.chat.toggled) return;

        // Build queue once
        if (!queued) {
            int cx = (int) Math.floor(mc.localPlayer.x);
            int cy = (int) Math.floor(mc.localPlayer.y);
            int cz = (int) Math.floor(mc.localPlayer.z);
            for (int layer = 0; layer < DEPTH; layer++) {
                int y = cy - 1 - layer;
                for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                    for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                        queue.add(new int[]{cx + dx, y, cz + dz});
                    }
                }
            }
            queued = true;
        }

        if (queue.isEmpty()) {
            setEnabled(false);
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastBreak < MS_PER_BREAK) return;
        lastBreak = now;

        // Try next block in queue — skip air, re-queue out-of-reach
        int attempts = 0;
        while (!queue.isEmpty() && attempts < 20) {
            int[] b = queue.poll();
            int bx = b[0], by = b[1], bz = b[2];
            attempts++;

            if (!mc.level.isSolidTile(bx, by, bz)) continue; // already air, skip

            double dx = bx + 0.5 - mc.localPlayer.x;
            double dy = by + 0.5 - mc.localPlayer.y;
            double dz = bz + 0.5 - mc.localPlayer.z;
            if (Math.sqrt(dx*dx + dy*dy + dz*dz) > 9.5) {
                queue.addLast(b); // out of reach, try later
                continue;
            }

            try {
                mc.level.setTile(bx, by, bz, 0);
                SocketClient.sendBlock(Packets.BLOCK_BREAK, bx, by, bz);
            } catch (Exception e) { }
            break;
        }
    }
}
