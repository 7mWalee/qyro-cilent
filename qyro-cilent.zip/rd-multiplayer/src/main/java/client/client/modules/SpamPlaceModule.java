package client.client.modules;

import client.Minecraft;
import client.client.module.Module;
import client.net.SocketClient;
import global.Packets;

public class SpamPlaceModule extends Module {

    private static final int  RADIUS     = 8;
    private static final int  BLOCK_ID   = 1; // Grass
    private static final long MS_PER_PLACE = 210;
    private long lastPlace = 0;

    public SpamPlaceModule() {
        super("SpamPlace", "Rapidly fills area with blocks", Category.MISC);
        setKeybind(org.lwjgl.input.Keyboard.KEY_INSERT);
    }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.mc;
        if (mc == null || mc.localPlayer == null || mc.level == null) return;
        if (mc.chat != null && mc.chat.toggled) return;

        long now = System.currentTimeMillis();
        if (now - lastPlace < MS_PER_PLACE) return;
        lastPlace = now;

        int cx = (int) Math.floor(mc.localPlayer.x);
        int cy = (int) Math.floor(mc.localPlayer.y);
        int cz = (int) Math.floor(mc.localPlayer.z);

        // Find first air block in radius and fill it
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                for (int dy = -2; dy <= 2; dy++) {
                    int bx = cx+dx, by = cy+dy, bz = cz+dz;
                    if (mc.level.isSolidTile(bx, by, bz)) continue;

                    double ddx = bx+0.5-mc.localPlayer.x;
                    double ddy = by+0.5-mc.localPlayer.y;
                    double ddz = bz+0.5-mc.localPlayer.z;
                    if (Math.sqrt(ddx*ddx+ddy*ddy+ddz*ddz) > 9.5) continue;

                    // Don't place where player is standing
                    if (Math.abs(bx-cx)<=1 && by>=cy-1 && by<=cy+1 && Math.abs(bz-cz)<=1) continue;

                    try {
                        mc.level.setTile(bx, by, bz, BLOCK_ID);
                        SocketClient.sendBlock(Packets.BLOCK_PLACE, bx, by, bz, BLOCK_ID);
                        return;
                    } catch (Exception e) { }
                }
            }
        }
    }
}
